package com.example.truck_taste.DTO;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CustomerDTO {
    @NotEmpty(message = "name should not be empty")
    @Pattern(regexp = "^[a-zA-Z ]+$")
    private  String userName;
    @NotNull(message = "password cannot be null")
    @Size(min = 6,message = "password must be more than 6 characters")
    private String password;
    @Email(message = "Enter valid email")
    @NotEmpty(message = "Email should not be empty")
    private  String email;
    @NotEmpty(message = "phone should not be empty")
    @Pattern(regexp = "^05\\d{8}$", message = "Invalid phone number format")
    private String phone;
    @Pattern(regexp = "^(CUSTOMER|FOODTRUCK|ADMIN)$")
    private String role;
}
