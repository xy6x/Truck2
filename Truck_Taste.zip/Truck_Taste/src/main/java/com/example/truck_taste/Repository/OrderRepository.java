package com.example.truck_taste.Repository;

import com.example.truck_taste.Model.Orders;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
@Repository
public interface OrderRepository extends JpaRepository<Orders,Integer> {
    Orders findOrderById(Integer id);

    @Query("select d from Orders d where d.date BETWEEN :start and :end")
    List<Orders> findOrdersByDateBetween(LocalDate start, LocalDate end);

//    List<Orders> findOrdersByTotalPrice(Double totalPrice);

    List<Orders> findOrdersByDateAfter(LocalDate date);

    Orders findOrdersByDateEquals(LocalDate date);
}