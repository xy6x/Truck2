package com.example.truck_taste.Repository;

import com.example.truck_taste.Model.Address;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AddressRepository extends JpaRepository<Address,Integer> {
        Address findAddressById(Integer id);
        Address findAddressByCity(String city);

        }
