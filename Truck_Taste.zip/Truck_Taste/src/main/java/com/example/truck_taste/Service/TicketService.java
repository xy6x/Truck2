package com.example.truck_taste.Service;

import com.example.truck_taste.ApiException.ApiException;
import com.example.truck_taste.DTO.TicketDTO;
import com.example.truck_taste.Model.Customer;
import com.example.truck_taste.Model.FoodTruck;
import com.example.truck_taste.Model.FoodTruck;
import com.example.truck_taste.Model.Orders;
import com.example.truck_taste.Model.Ticket;
import com.example.truck_taste.Repository.CustomerRepository;
import com.example.truck_taste.Repository.FoodTruckRepository;
import com.example.truck_taste.Repository.OrderRepository;
import com.example.truck_taste.Repository.TicketRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
@RequiredArgsConstructor
@Service
public class TicketService {
    private final TicketRepository ticketRepository;
    private final OrderRepository orderRepository;
    private final CustomerRepository customerRepository;
    private final FoodTruckRepository foodTruckRepository;
    public List<Ticket> getAllOrder(){
        return ticketRepository.findAll();
    }
    public void addTicket(TicketDTO ticketDTO){
        Orders order=orderRepository.findOrderById(ticketDTO.getOrder_id());
        if (order == null) {
            throw new ApiException("the order not found");
        }
        Customer customer = customerRepository.findCustomerById(order.getCustomer().getId());
        if (customer == null) {
            throw new ApiException("the id user not found");
        }
        FoodTruck foodTruck=foodTruckRepository.findFoodTruckById(ticketDTO.getFood_id());
        Ticket ticket=new Ticket(null,ticketDTO.getStatus(),order,foodTruck,customer);
        ticket.setStatus(null);
        ticketRepository.save(ticket);
    }
    public void updateTicket(Integer auth,TicketDTO ticketDTO){
        Ticket ticket=ticketRepository.findTicketById(auth);
        if (ticket == null) {
            throw new ApiException("the ticket not found");
        }


        ticket.setStatus(ticketDTO.getStatus());
        ticketRepository.save(ticket);


    }
    public void deleteTicket(Integer auth){
        Ticket ticket=ticketRepository.findTicketById(auth);
        if (ticket == null) {
            throw new ApiException("the id user not found");
        }
        ticketRepository.delete(ticket);
    }
    public Set<Ticket> findByUserId(Integer id){
        Customer customer= customerRepository.findCustomerById(id);
        if(customer==null){
            throw new ApiException(" user id not found");
        }
        return null;
//                customer.getTicket();
    }
}