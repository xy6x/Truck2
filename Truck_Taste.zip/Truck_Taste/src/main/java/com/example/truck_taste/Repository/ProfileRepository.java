package com.example.truck_taste.Repository;

import com.example.truck_taste.Model.Profiles;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProfileRepository extends JpaRepository<Profiles,Integer> {
    Profiles findProfileById(Integer id);
}