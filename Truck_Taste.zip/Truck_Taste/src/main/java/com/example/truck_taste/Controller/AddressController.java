package com.example.truck_taste.Controller;

import com.example.truck_taste.DTO.AddressDTO;
import com.example.truck_taste.Service.AddressService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/address")
public class AddressController {
    private final AddressService addressService;
    //admin
//    @GetMapping("/get")
//    public ResponseEntity GetAllAddress(){
//        return ResponseEntity.status(HttpStatus.OK).body(addressService);
//    }
    @PostMapping("/add")
    public  ResponseEntity AddAddress(@RequestBody @Valid AddressDTO addressDTO){
        addressService.addAddress(addressDTO);
        return ResponseEntity.status(HttpStatus.OK).body("added Address");
    }
    @PutMapping("/put/{id}")
    public ResponseEntity UpdateAddress(@PathVariable Integer id, @RequestBody @Valid AddressDTO addressDTO){
        addressService.updateAddress(id,addressDTO);
        return ResponseEntity.status(HttpStatus.OK).body("update Address");
    }
    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteAddress(@PathVariable Integer id){
        addressService.deleteAddress(id);
        return ResponseEntity.status(HttpStatus.OK).body("delete Address");
    }
    @GetMapping("/getByCity/{city}")
    public ResponseEntity getByCity(@PathVariable String city){
        return ResponseEntity.status(HttpStatus.OK).body(addressService.getByCity(city));
    }
    @GetMapping("/getByCustomerId/{id}")
    public ResponseEntity getByCustomerId(@PathVariable Integer id){
        return ResponseEntity.status(HttpStatus.OK).body(addressService.getByCustomerId(id));
    }
}

