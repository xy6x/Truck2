package com.example.truck_taste.Repository;

import com.example.truck_taste.Model.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoryRepository extends JpaRepository<Category,Integer> {
    Category findCategoriesById(Integer id);
    Category findCategoriesByName(String name);


}
