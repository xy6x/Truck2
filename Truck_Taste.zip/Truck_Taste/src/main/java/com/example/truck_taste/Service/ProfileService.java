package com.example.truck_taste.Service;

import com.example.truck_taste.ApiException.ApiException;
import com.example.truck_taste.DTO.ProfileDTO;
import com.example.truck_taste.Model.Customer;
import com.example.truck_taste.Model.Profiles;
import com.example.truck_taste.Repository.AddressRepository;
import com.example.truck_taste.Repository.CustomerRepository;
import com.example.truck_taste.Repository.ProfileRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@RequiredArgsConstructor
public class ProfileService {
    private final ProfileRepository profileRepository;
    private final CustomerRepository customerRepository;
    private final AddressRepository addressRepository;

    public List<Profiles> getProfile(){
        return profileRepository.findAll();
    }
    public void addProfile(ProfileDTO profileDTO){
        Customer customer = customerRepository.findCustomerById(profileDTO.getCustomer_id());
        if (customer == null) {
            throw new ApiException("the id customer not found");
        }
//        if (profileDTO.getCustomer_id()!=auth) {
//            throw new ApiException("the user not Authorized");
//        }

        Profiles profile=new Profiles(null, profileDTO.getDescription(), profileDTO.getAccountCreationDate(),customer,null);
        profileRepository.save(profile);
    }
    public void updateProfile(Integer id,ProfileDTO profileDTO){
        Profiles profile=profileRepository.findProfileById(id);
        if (profile == null) {
            throw new ApiException("the id profile not found");
        }
        Customer customer = customerRepository.findCustomerById(profileDTO.getCustomer_id());
        if (customer == null) {
            throw new ApiException("the id customer not found");
        }
//        if (profile.getCustomer().getId()!=auth) {
//            throw new ApiException("the user not Authorized");
//        }

        profile.setDescription(profileDTO.getDescription());
        profile.setAccountCreationDate(profileDTO.getAccountCreationDate());
        profileRepository.save(profile);


    }
    public void deleteProfile(Integer auth){
        Profiles profile=profileRepository.findProfileById(auth);
        if (profile == null) {
            throw new ApiException("the id user not found");
        }
        profileRepository.delete(profile);
    }
    public Profiles findUserById(Integer id){
        Customer customer= customerRepository.findCustomerById(id);
        if(customer==null){
            throw new ApiException("customer id not found");
        }
        return customer.getProfiles();
    }


}
