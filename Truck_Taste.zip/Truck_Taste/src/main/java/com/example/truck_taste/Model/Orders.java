package com.example.truck_taste.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Set;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Orders {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(columnDefinition ="DATE")
    private LocalDate date;
//    @NotNull(message = "number of day should not be empty")
    @Column(columnDefinition = "int not null")
    private Integer numberOfDay;
    private Float totalPrice;
//    @Pattern(regexp = "^(Complete|Uncomplete)$",message = "status must be Complete or UnComplete")
//    @Column(columnDefinition = "varchar(10) Check(orderStatus='Complete' or orderStatus='UnComplete')")
    private String orderStatus;
    @Column(columnDefinition = "varchar(50)")
    private String note;
    @Column(columnDefinition = "float")
    private Float discount;
    @OneToOne(cascade = CascadeType.ALL,mappedBy = "order")
    @PrimaryKeyJoinColumn
    private Ticket ticket;
    @ManyToOne
    @JsonIgnore
    private FoodTruck foodTruck;
    @ManyToOne
    @JoinColumn(name = "address_id",referencedColumnName = "id")
    private Address address;
    @ManyToOne
//    @JoinColumn(name = "customer_id",referencedColumnName = "id")
    @JsonIgnore
    private Customer customer;

    @OneToMany(cascade = CascadeType.ALL,mappedBy = "orders")
    private Set<Evaluation> evaluations;

}
