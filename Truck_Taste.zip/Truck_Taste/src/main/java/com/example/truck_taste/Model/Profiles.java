package com.example.truck_taste.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Profiles {
    @Id
    private Integer id;
//    @NotNull(message = "Summary should not be empty")
    @Column(columnDefinition = "varchar(100) not null")
    private String description;
    @Column(columnDefinition = "DATE")
    private LocalDateTime AccountCreationDate =LocalDateTime.now();
    @OneToOne
    @JsonIgnore
    private Customer customer;

    @OneToMany(cascade = CascadeType.ALL,mappedBy ="profiles")
    @PrimaryKeyJoinColumn
    private Set<Address> addresses;

}
