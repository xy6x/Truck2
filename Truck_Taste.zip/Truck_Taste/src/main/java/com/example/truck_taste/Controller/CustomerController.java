package com.example.truck_taste.Controller;

import com.example.truck_taste.DTO.CustomerDTO;
import com.example.truck_taste.Service.CustomerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/user")
public class CustomerController {
    private final CustomerService customerService;
    // ADMIN
    @GetMapping("/get")
    public ResponseEntity GetAllUser(){
        return ResponseEntity.status(HttpStatus.OK).body(customerService.getAll());
    }
    @PostMapping("/add")
    public ResponseEntity AddUser(@RequestBody @Valid CustomerDTO customerDTO){
        customerService.addCustomer(customerDTO);
        return ResponseEntity.status(HttpStatus.OK).body("added Client");
    }
//    @PutMapping("/put/{id}")
//    public ResponseEntity UpdateUser( @RequestBody @Valid CustomerDTO customerDTO){
//        customerService.updateCustomer(customerDTO);
//        return ResponseEntity.status(HttpStatus.OK).body("update Customer");
//    }
    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteUser(@PathVariable Integer id){
        customerService.deleteCustomer(id);
        return ResponseEntity.status(HttpStatus.OK).body("delete Customer");
    }


    @GetMapping("/food/{number}")
    public ResponseEntity food(@PathVariable Integer number){
        return ResponseEntity.status(200).body(customerService.currentStatus(number));
    }
    @GetMapping("/check")
    public ResponseEntity check(){

        return ResponseEntity.status(200).body(customerService.checkIfFoodTruckAvailable());
    }
    @GetMapping("/best/{number}/{re}")
    public ResponseEntity  best(@PathVariable Double number,@PathVariable Integer re){
        return ResponseEntity.status(200).body(customerService.HighestRating(number,re));
    }
    @GetMapping("/foodTruckAcceptCheck/{admin_id}/{food_id}")
    public ResponseEntity  foodTruckAcceptCheck(@PathVariable Integer admin_id,@PathVariable Integer food_id ){
        customerService.FoodTruckAcceptCheck(food_id,admin_id);
        return ResponseEntity.status(200).body("Food Truck Accept Check");
    }



}
