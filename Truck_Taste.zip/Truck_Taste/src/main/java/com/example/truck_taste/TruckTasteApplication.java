package com.example.truck_taste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TruckTasteApplication {

    public static void main(String[] args) {
        SpringApplication.run(TruckTasteApplication.class, args);
    }

}
