package com.example.truck_taste.ApiException;

public class ApiException extends RuntimeException{
    public ApiException(String message){
        super(message);
    }
}