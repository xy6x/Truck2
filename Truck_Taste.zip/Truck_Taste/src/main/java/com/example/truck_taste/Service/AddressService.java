package com.example.truck_taste.Service;

import com.example.truck_taste.ApiException.ApiException;
import com.example.truck_taste.DTO.AddressDTO;
import com.example.truck_taste.Model.Address;
import com.example.truck_taste.Model.Customer;
import com.example.truck_taste.Model.Profiles;
import com.example.truck_taste.Repository.AddressRepository;
import com.example.truck_taste.Repository.CustomerRepository;
import com.example.truck_taste.Repository.ProfileRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
@Service
@RequiredArgsConstructor
public class AddressService {
    private final AddressRepository addressRepository;
    private final CustomerRepository customerRepository;
    private final ProfileRepository profileRepository;
     List<Address> getAll(){

        return addressRepository.findAll();
    }
    public void addAddress(AddressDTO addressDTO){
//        Customer customers=customerRepository.findCustomerById(addressDTO.getCustomer_id());
//        if (customers == null) {
//            throw new ApiException("the user not found");
//        }
        Profiles profiles =profileRepository.findProfileById(addressDTO.getProfile_id());
        if (profiles == null) {
            throw new ApiException("the id profile not found");
        }
        Customer customer =customerRepository.findCustomerById(profiles.getCustomer().getId());
        if (customer == null) {
            throw new ApiException("the id user not found");
        }
//        if (addressDTO.getCustomer_id()!=id) {
//            throw new ApiException("the user not Authorized");
//        }
        Address address =new Address(null,addressDTO.getCity(),addressDTO.getStreet(), profiles,null);
        addressRepository.save(address);
    }
    public void updateAddress(Integer id,AddressDTO addressDTO) {
        Address address=addressRepository.findAddressById(addressDTO.getProfile_id());
        if (address == null) {
            throw new ApiException("the id address not found");
        } Customer customer = customerRepository.findCustomerById(addressDTO.getCustomer_id());
        if (customer == null) {
            throw new ApiException("the id customer not found");
        }
//        if (address.getProfiles().getCustomer().getId()!=auth) {
//            throw new ApiException("the user not Authorized");
//        }


        address.setCity(addressDTO.getCity());
        address.setStreet(addressDTO.getStreet());
        addressRepository.save(address);
    }
    public void deleteAddress(Integer id){
        Address address = addressRepository.findAddressById(id);
        if (address == null) {
            throw new ApiException("the id nt found");
        }Customer customer = customerRepository.findCustomerById(address.getId());
        if (customer == null) {
            throw new ApiException("the id customer not found");
        }
//        if (address.getProfiles().getCustomer().getId()!=auth) {
//            throw new ApiException("the user not Authorized");
//        }
        addressRepository.delete(address);
    }
    public Address getByCity(String city){
        Address address=addressRepository.findAddressByCity(city);
        if(address==null){
            throw new ApiException("address not found");
        }
        return null;
    }
    public Set<Address> getByCustomerId(Integer id){
        Customer customer =customerRepository.findCustomerById(id);
        if(customer==null){
            throw new ApiException("user not found");
        }
        return customer.getProfiles().getAddresses();
    }
}

