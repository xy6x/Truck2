package com.example.truck_taste.Service;

import com.example.truck_taste.ApiException.ApiException;
import com.example.truck_taste.DTO.FoodTruckDTO;
import com.example.truck_taste.Model.*;
import com.example.truck_taste.Repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
@RequiredArgsConstructor
@Service
public class FoodTruckService {
    private final FoodTruckRepository foodTruckRepository;
    private final TicketRepository ticketRepository;
    private final CategoryRepository categoryRepository;
    private final EvaluationRepository evaluationRepository;
    private final UserRepository userRepository;
    public List<FoodTruck> getAll() {
        return foodTruckRepository.findAll();
    }

    public void addFood(FoodTruckDTO foodTruckDTO) {

        User user=new User(null,foodTruckDTO.getUserName(),foodTruckDTO.getPassword(),foodTruckDTO.getEmail(),foodTruckDTO.getPhone(),foodTruckDTO.getRole(),null,null);
        user.setRole("FOODTRUCK");

//        String hash=new BCryptPasswordEncoder().encode(user.getPassword());
//        user.setPassword(hash);
        userRepository.save(user);
        FoodTruck foodTruck=new FoodTruck(null,foodTruckDTO.getLicense(),foodTruckDTO.getName(),foodTruckDTO.getNumberOfEmployee(),foodTruckDTO.getCity(),foodTruckDTO.getStatus(),foodTruckDTO.getRating(),foodTruckDTO.getRequests(),null,user,null,null,null,null);
        foodTruck.setIsChecked(false);
        foodTruckRepository.save(foodTruck);
    }

    public void updateFoodTruck( FoodTruckDTO foodTruck) {
        FoodTruck oldFoodTruck = foodTruckRepository.findFoodTruckById(foodTruck.getId());
        if (oldFoodTruck == null) {
            throw new ApiException("the id nt found");
        }

        oldFoodTruck.setName(foodTruck.getName());
        oldFoodTruck.setCity(foodTruck.getCity());
        oldFoodTruck.setLicense(foodTruck.getLicense());
        foodTruckRepository.save(oldFoodTruck);

    }

    public void deleteFoodTruck(Integer auth) {
        FoodTruck food = foodTruckRepository.findFoodTruckById(auth);
        if (food == null) {
            throw new ApiException("the id nt found");
        }
        foodTruckRepository.delete(food);
    }

    public Set<FoodTruck> findOrderByCategory(String category) {
        Category categor = categoryRepository.findCategoriesByName(category);
        if (categor == null) {
            throw new ApiException("Category not found");
        }
        return  null;// categor.getFoodTrucks();
    }
    public void acceptOrder(Integer id) {
        Ticket ticket = ticketRepository.findTicketById(id);

        if (ticket == null) {
            throw new ApiException("the id nt found");
        }

        if (ticket.getOrder().getFoodTruck().getStatus().equals("Available")){
            if(ticket.getStatus()==null) {
                ticket.getOrder().getFoodTruck().setStatus("tenant");
                if (ticket.getOrder().getFoodTruck().getRequests() == null) {
                    ticket.getOrder().getFoodTruck().setRequests(0);
                }
                ticket.getOrder().getFoodTruck().setRequests(ticket.getOrder().getFoodTruck().getRequests() + 1);
                foodTruckRepository.save(ticket.getOrder().getFoodTruck());
                ticket.setStatus("Accept");
                ticketRepository.save(ticket);

            } else throw new ApiException("the food  tenant");
        }else throw new ApiException("the food  2");
    }

    public void rejectOrder(Integer id) {
        Ticket ticket = ticketRepository.findTicketById(id);

        if (ticket == null) {
            throw new ApiException("the id nt found");
        }
        if (ticket.getOrder().getFoodTruck().getStatus().equals("avalaible") && ticket.getStatus().equals("null") ) {
            ticket.setStatus("Reject");
            ticketRepository.save(ticket);
        } else throw new ApiException("the food  tenant");
    }


    public void endOrder(Integer id) {
        FoodTruck foodTruck = foodTruckRepository.findFoodTruckById(id);
        if (foodTruck == null) {
            throw new ApiException("the id nt found");
        }
        if (foodTruck.getStatus().equals("zz")) {
            foodTruck.setStatus("ava");
            foodTruckRepository.save(foodTruck);
        } else throw new ApiException("the food not zz ");
    }

    public void getAverageRatingForFood(Integer food_id) {
        FoodTruck foodTruck = foodTruckRepository.findFoodTruckById(food_id);
        List<Evaluation> evaluations = evaluationRepository.findAllByFoodTruckId(food_id);
        if (foodTruck == null) {
            throw new ApiException("food Truck id incorrect");
        }
        float totalRating = evaluations.stream().mapToInt(Evaluation::getRating).sum();
//        foodTruck.setRating(totalRating / evaluations.size());
        foodTruck.setRating(totalRating/evaluations.size());
        foodTruckRepository.save(foodTruck);
    }

    public List<FoodTruck> findFoodTruckByRating(Double min, Double max) {
        List<FoodTruck> foodTruck = foodTruckRepository.findFoodTruckByRating(min, max);
        if (foodTruck == null) {
            throw new ApiException("food Truck id incorrect");
        }
        return foodTruck;
    }


    public Services getByFoodTruckName(String name){
        FoodTruck foodTruck=foodTruckRepository.findFoodTruckByName(name);
        if (foodTruck == null) {
            throw new ApiException("food truck not found");
        }
        return foodTruck.getServices();
    }
    public List<FoodTruck> getAllFoodTruckNotChecked() {
        List<FoodTruck> food = foodTruckRepository.getAllFoodTruckNotChecked();
        if (food.isEmpty()) {
            throw new ApiException("All Food Truck checked");
        }
        return food;
    }

}
